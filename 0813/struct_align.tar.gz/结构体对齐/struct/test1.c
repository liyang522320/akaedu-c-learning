#include <stdio.h>

//#define DEBUG

struct node {
	char name[10];
	char sex;
	int id;
	float goal;
}__attribute__((packed, aligned(8)))Node;

struct Stud {
	char name[10];
	int id;
	char sex;
	float goal;
}Student;
struct Teacher {
	char name[10];
	char sex;
	int id;
	float goal;
}teacher;

#ifndef DEBUG
struct Total {
	struct node Node;
	struct Stud stud1;
	struct Teacher teach;
	double ch;
	double id;
} total;
#else
struct Sum {
	struct node Node;
	struct Stud stud1;
	struct Teacher teach;
}__attribute__((packed, aligned(4))) sum1;
#endif
//#pragma pack(pop);
int main(void)
{
	printf("sizeof(Node) = %d\n", sizeof(Node));
	printf("sizeof(Student) = %d\n", sizeof(Student));   /* */
	printf("sizeof(teacher) = %d\n", sizeof(teacher));
#if defined(DEBUG)
	printf("sizoef(sum1) = %d\n", sizeof(sum1));
#else
	printf("sizoef(total) = %d\n", sizeof(total));
#endif

	return 0;
}
