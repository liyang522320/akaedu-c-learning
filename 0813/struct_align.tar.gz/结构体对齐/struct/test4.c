#include <stdio.h>

struct A {
	char a;
	long b;
}__attribute__((packed, aligned(1)));

struct B {
	char a;
	struct A b;
	double c;
};
struct C {
	char name[6];
	short id;
	double goal;
};
struct D {
	int a:8;
	int b:2;
	int c:6;
};
int main(void)
{
	struct D d;
	printf("sizeof(struct A) = %d\n", sizeof(struct A));
	printf("sizeof(struct B) = %d\n", sizeof(struct B));
	printf("sizeof(struct C) = %d\n", sizeof(struct C));
	printf("sizeof(struct D) = %d\n", sizeof(struct D));
//	printf("&d.a = %p, &d.b = %p, &d.c = %p\n", &d.a, &d.b, &d.c);  
									/* 内存是以字节为单位的，所以不能够打印位域的地址*/
	return 0;
}
