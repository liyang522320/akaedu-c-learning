#include <stdio.h>


int main(void)
{
	struct A {
		char a;
		long b;
	};

	struct B {
		char a;
		struct A b;
		long c;
	};
	
	struct C {
		char a;
		struct A b;
		double c;
	};

	struct D {
		char a;
		struct A b;
		double c;
		int d;
	};

	struct E {
		char a;
		int b;
		struct A c;
		double d;
	};
	
	printf("sizeof(struct A) = %d\n", sizeof(struct A));
	printf("sizeof(struct B) = %d\n", sizeof(struct B));
	printf("sizeof(struct C) = %d\n", sizeof(struct C));
	printf("sizeof(struct D) = %d\n", sizeof(struct D));
	printf("sizeof(struct E) = %d\n", sizeof(struct E));

	return 0;
}
