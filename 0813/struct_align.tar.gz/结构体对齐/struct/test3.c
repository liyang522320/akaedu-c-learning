#include <stdio.h>

int main(void)
{
	struct num {
		char ch;
		long double ld;
	}__attribute__((packed, aligned(32)))num1;
	struct A {
		short a1;
		short a2;
		short a3;
	}__attribute__((packed, aligned(16))) A1;
	struct B {
		long a1;
		struct A a;
	}B1;
	printf ("%d\n", sizeof(num1));
	printf ("&num1.ch = %p, &num1.ld = %p\n", &num1.ch, &num1.ld);
	printf ("sizeof(A1) = %d\n", sizeof(A1));
	printf ("&A1.a1 = %p, &A1.a2  = %p\n", &A1.a1, &A1.a2);
	printf ("sizeof(B1) = %d\n", sizeof(B1));
	printf ("&B1.a1 = %p, &B1.a.a1  = %p, &B1.a.a2 = %p\n", &B1.a1, &B1.a.a1, &B1.a.a2);

	return 0;
}
